# Huescribe: Chrome Web Store kit

Everything in this folder goes into the Chrome Web Store Developer Dashboard. Nothing here needs filling in: copy each block into the matching field.

## What's in the kit

| File | Where it goes |
|---|---|
| `huescribe.zip` | Package tab → Upload new package |
| `icon-store-128.png` | Store listing → Store icon (128×128, artwork 96×96 with 16 px clear padding) |
| `screenshot-1.png` … `screenshot-3.png` | Store listing → Screenshots (1280×800, in this order) |
| `promo-small-440x280.png` | Store listing → Small promo tile |
| `promo-marquee-1400x560.png` | Store listing → Marquee promo tile (optional, needed to be featured) |
| `huescribe-website.zip` | Your website host (see step 2) |

## Step by step

1. **Developer account.** Open the Chrome Web Store Developer Dashboard (chrome.google.com/webstore/devconsole) with the Google account that should own Huescribe. Accept the developer agreement and pay the one-time registration fee ($5 at the time of writing; the dashboard shows the current amount). Verify the contact email it asks for: Google sends review notices there, and it's how people reach you from the listing's Support tab.
2. **Put the website online** (the listing needs a privacy policy link). Unzip `huescribe-website.zip` and drag the folder onto app.netlify.com/drop (or any static host). Your privacy policy is then at `https://<your-site>/privacy.html`.
3. **Add the item.** In the dashboard: Add new item → upload `huescribe.zip`.
4. **Store listing tab.** Paste the texts below and upload the images.
5. **Privacy tab.** Paste the answers below and the privacy policy link from step 2.
6. **Distribution tab.** Visibility: Public. Regions: all. Pricing: free.
7. **Submit for review.** Reviews usually take a few days, sometimes longer for extensions that can read all sites. You'll get an email either way.
8. **After it's live,** the "Add Huescribe to Chrome" buttons on the website already work: they open a Chrome Web Store search for Huescribe.

## Store listing

**Name** (comes from the package): Huescribe: turn website design into AI prompts

**Summary** (comes from the package, 123 of 132 characters):
Click the parts you like on any website and get a ready-to-paste prompt for Claude Code, Cursor, Lovable and other AI apps.

**Category:** Developer Tools
**Language:** English

**Description:**

```
See a design you love? Bring it to your own site.

Huescribe is a side panel for Chrome. Click the parts of a website you like (a pricing table, a hero section, a button with a great hover) and it writes them up as one clear prompt for the AI app you build with: Claude Code, Cursor, ChatGPT, Lovable, v0, Bolt, Windsurf, Copilot or Gemini.

How it works
1. Click anything on the page. Use the arrow keys to grow the pick to a whole section, or drag a box around any area.
2. Choose what you want from it: colors, fonts, layout or motion. Take only what you need; your site keeps the rest of its own style.
3. Copy the prompt and paste it into your AI app. That's it.

What it picks up
• Colors and contrast, nudged a little so you never end up with a copy
• Fonts, type sizes and weights, mapped onto the fonts you already use
• Layout, columns and spacing
• Hover effects, presses and animations, with their timing and easing
• Scroll effects

Made for borrowing ideas, not cloning pages
Huescribe describes design. It never takes a site's text, photos, logos or code, and the prompt tells your AI app to keep your own words, pictures and brand.

Private by design
Huescribe runs entirely in your browser. There's no account, no analytics and no Huescribe server. It reads a page only when you pick something there, and it switches off completely when you close the panel.
```

## Privacy tab

**Single purpose:**
Huescribe turns parts of a website the user picks into a written design prompt (colors, fonts, layout and motion) that the user pastes into an AI coding app.

**Permission justifications:**

- **activeTab:** Lets Huescribe draw the picking outline on the tab the user is looking at and take a screenshot of the visible tab, cropped to the part the user picked, so the panel can show a small picture of it.
- **scripting:** Adds the picking outline and the design reader to the page only after the user opens the Huescribe panel, and removes them when the panel closes.
- **storage:** Keeps the user's list of picked parts (session storage, cleared when the browser closes) and their settings, such as the chosen AI app and their own standing instructions, on their device.
- **sidePanel:** Opens Huescribe as a panel next to the page, so the user can pick parts while seeing the site.
- **Host permission (all sites):** The user can pick design details on any website they choose. Huescribe reads the part they pick and downloads that page's own CSS files to describe the design accurately. It does nothing on a page until the user opens the panel and picks something there.

**Are you using remote code?** No, I am not using remote code. (All scripts are inside the package.)

**Data usage: what user data do you plan to collect?** Tick nothing. Huescribe doesn't send any data off the user's device: what it reads stays in the browser, and the prompt goes only to the clipboard.

**Certifications:** Tick all three:
- I do not sell or transfer user data to third parties, outside of the approved use cases.
- I do not use or transfer user data for purposes that are unrelated to my item's single purpose.
- I do not use or transfer user data to determine creditworthiness or for lending purposes.

**Privacy policy URL:** `https://<your-site>/privacy.html` (from step 2).

## Test instructions for the reviewer (optional field)

```
No account or setup needed. Open any website, click the Huescribe icon (or press Alt+Shift+P) to open the side panel, then click a section of the page. Choose Colors and Layout, press "Add to my list", then "Copy prompt". The prompt is on the clipboard.
```
