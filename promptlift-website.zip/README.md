# PromptLift website: how to publish

This folder is the whole website: plain HTML, CSS and a little JavaScript. It needs no build step and no server code, so any static host works (Netlify, Cloudflare Pages, Vercel, GitHub Pages, or your own server).

## 1. Fill in `settings.js`

Open `settings.js` in any text editor and fill in the values between the quotes:

| Setting | What it is | Where it shows |
|---|---|---|
| `storeUrl` | Your Chrome Web Store link | Every "Add PromptLift to Chrome" button |
| `contactEmail` | Where people can reach you | Fine print, privacy policy, terms |
| `companyName` | The legal name of the person or company offering PromptLift | Footer, privacy policy, terms |
| `governingLaw` | Whose law governs the terms, e.g. `the State of Delaware, USA` | Terms of use |
| `priceAnswer` | The answer to "Is PromptLift free?" | FAQ (the question is hidden while this is empty) |
| `guides` | The four guide videos (file name, optional poster image, length) | "Minute-long tours" |

Anything you leave empty shows as a [bracketed placeholder], and the browser console lists what's still missing.

## 2. Add your images and videos to `images/`

| File | What | Notes |
|---|---|---|
| `share.jpg` | The picture shown when the site is shared in chats and on social media | A ready-made one is included; replace it with your own if you like (1200 × 630 px, same name) |
| `guide-1.mp4` … `guide-4.mp4` | The four guide videos | Vertical (9:16), under a minute; then write their names in `settings.js` → `guides` |
| `guide-1.jpg` … (optional) | A still shown before each video plays | Write the names in `settings.js` → `guides` → `poster` |

To swap any other picture (the flower photos, the app screenshots), replace the file in `images/` and keep its name.

## 3. Put in your domain

Find `YOUR-DOMAIN.com` and replace it with your real address (for example `promptlift.app`). It appears in:
`index.html`, `privacy.html`, `terms.html`, `robots.txt` and `sitemap.xml`.
Most editors can do this in one go ("Replace in files"), or ask Claude to do it.

## 4. Upload

- **Netlify:** drag this folder onto app.netlify.com/drop.
- **Cloudflare Pages:** create a project → "Upload assets" → choose this folder.
- **GitHub Pages:** put the files in a repository and turn on Pages for it.

Then connect your domain in the host's settings.

## 5. Before you go live

- [ ] `settings.js` filled in (open the site, press F12 → Console: no "settings still to fill in" line).
- [ ] Every "Add PromptLift to Chrome" button opens your Chrome Web Store page.
- [ ] `YOUR-DOMAIN.com` replaced everywhere.
- [ ] The privacy policy and terms of use read right for your business. They were written to match what the extension really does, but they are not legal advice: have a lawyer review them, especially if you charge money or sell outside the US.
- [ ] Use the privacy policy's address (`https://your-domain/privacy.html`) in the Chrome Web Store listing.
- [ ] Share the address in a chat to check the preview picture appears.
