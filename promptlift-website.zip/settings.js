/*
 * PromptLift website settings: the one place to fill in before publishing.
 * Edit the values between the quotes, save, and upload the site again. Every page reads this file.
 * Anything left empty shows as a [bracketed placeholder] on the page, and the browser console lists what is still missing.
 */
window.SITE_SETTINGS = {
  // The Chrome Web Store page of the extension. Every "Add PromptLift to Chrome" button goes here.
  // Example: "https://chromewebstore.google.com/detail/promptlift/abcdefghijklmnopabcdefghijklmnop"
  storeUrl: "",

  // Where people can reach you (shown in the fine print, the privacy policy and the terms).
  // Example: "hello@promptlift.app"
  contactEmail: "",

  // The legal name of the person or company that offers PromptLift (footer, privacy policy, terms).
  // Example: "PromptLift LLC"
  companyName: "",

  // Whose law governs the terms of use. Example: "the State of Delaware, USA"
  governingLaw: "",

  // The answer to "Is PromptLift free?" in the FAQ. Leave empty to hide that question.
  // Example: "Yes. PromptLift is free to install and use, with no account."
  priceAnswer: "",

  // The four short videos in "Minute-long tours", left to right.
  // Put the files in the images folder and write their names here, e.g. video: "images/guide-1.mp4".
  // poster is an optional still shown before the video plays; length is shown in the corner, e.g. "0:42".
  // A guide with no video keeps its dark placeholder.
  guides: [
    { video: "", poster: "", length: "" }, // Pick a whole section
    { video: "", poster: "", length: "" }, // Just the colors, please
    { video: "", poster: "", length: "" }, // Catch a hover effect
    { video: "", poster: "", length: "" }  // Hand it to your AI app
  ]
};
