/*
 * Applies settings.js to the page: store links, contact email, company name, governing law, the price answer and the
 * guide videos. Runs on every page. Missing settings keep their [bracketed placeholder] and are listed in the console.
 */
(function () {
  'use strict';
  var S = window.SITE_SETTINGS || {};
  var missing = [];
  var has = function (v) { return typeof v === 'string' && v.trim() !== ''; };
  var each = function (sel, fn) { Array.prototype.forEach.call(document.querySelectorAll(sel), fn); };

  function apply() {
    // Store links: the real store page when set; otherwise they scroll to the closing section of the homepage.
    if (has(S.storeUrl)) {
      each('[data-store-link]', function (a) { a.href = S.storeUrl; a.rel = 'noopener'; });
    } else if (document.querySelector('[data-store-link]')) {
      missing.push('storeUrl');
    }

    // Contact email: a mailto link wherever [data-contact] appears.
    each('[data-contact]', function (a) {
      if (has(S.contactEmail)) { a.href = 'mailto:' + S.contactEmail.trim(); a.textContent = S.contactEmail.trim(); }
      else { a.removeAttribute('href'); }
    });
    if (!has(S.contactEmail) && document.querySelector('[data-contact]')) missing.push('contactEmail');

    // Plain text values.
    [['companyName', '[data-company]'], ['governingLaw', '[data-law]']].forEach(function (pair) {
      var key = pair[0], sel = pair[1];
      if (!document.querySelector(sel)) return;
      if (has(S[key])) each(sel, function (el) { el.textContent = S[key].trim(); });
      else missing.push(key);
    });
    each('[data-year]', function (el) { el.textContent = String(new Date().getFullYear()); });

    // FAQ: "Is PromptLift free?" shows only once there is an answer.
    var price = document.getElementById('faq-price');
    if (price) {
      if (has(S.priceAnswer)) { var p = price.querySelector('p'); if (p) p.textContent = S.priceAnswer.trim(); }
      else { price.remove(); missing.push('priceAnswer'); }
    }

    // Guide videos: replace a placeholder with the real video when one is set.
    var guides = Array.isArray(S.guides) ? S.guides : [];
    each('[data-guide]', function (box) {
      var g = guides[Number(box.getAttribute('data-guide')) - 1] || {};
      if (!has(g.video)) return;
      var v = document.createElement('video');
      v.src = g.video.trim();
      if (has(g.poster)) v.poster = g.poster.trim();
      v.controls = true; v.preload = 'metadata'; v.playsInline = true;
      v.setAttribute('aria-label', (box.closest('li') && box.closest('li').querySelector('h3') || {}).textContent || 'Guide video');
      v.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#1b1b1a';
      v.addEventListener('error', function () {
        // Keep the placeholder visible and tell the developer which file failed to load.
        console.warn('[PromptLift site] guide video could not load:', v.src);
        v.remove();
      });
      box.appendChild(v);
      var tag = box.querySelector('[data-guide-length]');
      if (tag) { if (has(g.length)) tag.textContent = g.length.trim(); else tag.remove(); }
    });

    if (missing.length) console.info('[PromptLift site] settings still to fill in settings.js:', missing.join(', '));
  }

  try { apply(); } catch (err) { console.error('[PromptLift site] could not apply settings.js', err); }
})();
